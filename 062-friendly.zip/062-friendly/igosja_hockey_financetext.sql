-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `financetext`
--

DROP TABLE IF EXISTS `financetext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financetext` (
  `financetext_id` int(2) NOT NULL AUTO_INCREMENT,
  `financetext_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`financetext_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financetext`
--

LOCK TABLES `financetext` WRITE;
/*!40000 ALTER TABLE `financetext` DISABLE KEYS */;
INSERT INTO `financetext` VALUES (1,'VIP-призовые'),(2,'Призовые за чемпионат мира'),(3,'Призовые за Лигу чемпионов'),(4,'Призовые за чемпионат страны'),(5,'Призовые за конференцию любительских клубов'),(6,'Призовые за кубок межсезонья'),(7,'Доход от продажи билетов'),(8,'Расходы на организацию матча'),(9,'Зарплата игроков'),(10,'Оплата тренировки совмещения игрока {player}'),(11,'Оплата тренировки спецвозможности игрока {player}'),(12,'Оплата тренировки балла силы игрока {player}'),(13,'Оплата изучения стиля игрока {player}'),(14,'Оплата расширения стадиона до {capacity} мест'),(15,'Компенсация за уменьшения стадиона до {capacity} мест'),(16,'Оплата увеличения уровня строения {building} до {level} уровня'),(17,'Компенсация за уменьшение строения {building} до {level} уровня'),(18,'Продажа игрока {player}'),(19,'Покупка игрока {player}'),(20,'Первой команде за трансфер игрока {player}'),(21,'Игрок {player} взят в аренду'),(22,'Игрок {player} отдан в аренду'),(23,'Содержание базы за сезон'),(24,'Перерегистрация команды'),(25,'Уход на пенсию игрока'),(26,'Компенсиция за участие в матчах сборной игрока {player}'),(27,'Перевод с личного счета менеджера'),(28,'Бонус по партнёрской программе'),(29,'Перевод сo счета федерации');
/*!40000 ALTER TABLE `financetext` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:38
