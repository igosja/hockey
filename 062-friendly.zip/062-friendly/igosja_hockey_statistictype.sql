-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `statistictype`
--

DROP TABLE IF EXISTS `statistictype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statistictype` (
  `statistictype_id` int(2) NOT NULL AUTO_INCREMENT,
  `statistictype_name` varchar(255) DEFAULT NULL,
  `statistictype_order` int(2) DEFAULT '0',
  `statistictype_statisticchapter_id` int(1) DEFAULT '0',
  PRIMARY KEY (`statistictype_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistictype`
--

LOCK TABLES `statistictype` WRITE;
/*!40000 ALTER TABLE `statistictype` DISABLE KEYS */;
INSERT INTO `statistictype` VALUES (1,'Игры без пропущенных шайб',0,1),(2,'Игры без заброшенных шайб',0,1),(3,'Поражения',0,1),(4,'Поражения по буллитам',0,1),(5,'Поражения в дополнительное время',0,1),(6,'Пропущенные шайбы',0,1),(7,'Заброшенные шайбы',0,1),(8,'Штрафные минуты',0,1),(9,'Штрафные минуты соперника',0,1),(10,'Победы',0,1),(11,'Победы по буллитам',0,1),(12,'Победы в дополнительное время',0,1),(13,'Процент побед',0,1),(14,'Результативные передачи',0,2),(15,'Результативные передачи в большинстве',0,2),(16,'Результативные передачи в меньшинстве',0,2),(17,'Победные буллиты',0,2),(18,'Вбрасывания',0,2),(19,'Процент выигранных вбрасываний',0,2),(20,'Выигранные вбрасывания',0,2),(21,'Игры',0,2),(22,'Поражения',0,2),(23,'Пропущенные шайбы',0,2),(24,'Пропущенные шайбы за игру',0,2),(25,'Штрафные минуты',0,2),(26,'Плюс/минус',0,2),(27,'Очки (шайбы+голевые передачи)',0,2),(28,'Отраженные броски',0,2),(29,'Процент отраженных бросков',0,2),(30,'Заброшенные шайбы',0,2),(31,'Заброшенные шайбы, которые сравняли счет в матче',0,2),(32,'Заброшенные шайбы в большинстве',0,2),(33,'Заброшенные шайбы в меньшинстве',0,2),(34,'Процент заброшенных шайб к количеству бросков по воротам',0,2),(35,'Победные шайбы',0,2),(36,'Броски по воротам',0,2),(37,'Броски (вратари)',0,2),(38,'Броски за игру',0,2),(39,'Игры на ноль',0,2),(40,'Победы',0,2);
/*!40000 ALTER TABLE `statistictype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:33
