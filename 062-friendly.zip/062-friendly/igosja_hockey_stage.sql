-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stage`
--

DROP TABLE IF EXISTS `stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stage` (
  `stage_id` int(2) NOT NULL AUTO_INCREMENT,
  `stage_name` varchar(255) DEFAULT NULL,
  `stage_visitor` int(3) DEFAULT NULL,
  PRIMARY KEY (`stage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage`
--

LOCK TABLES `stage` WRITE;
/*!40000 ALTER TABLE `stage` DISABLE KEYS */;
INSERT INTO `stage` VALUES (1,'-',90),(2,'1 тур',100),(3,'2 тур',100),(4,'3 тур',100),(5,'4 тур',100),(6,'5 тур',100),(7,'6 тур',100),(8,'7 тур',100),(9,'8 тур',100),(10,'9 тур',100),(11,'10 тур',100),(12,'11 тур',100),(13,'12 тур',100),(14,'13 тур',100),(15,'14 тур',100),(16,'15 тур',100),(17,'16 тур',100),(18,'17 тур',100),(19,'18 тур',100),(20,'19 тур',100),(21,'20 тур',100),(22,'21 тур',100),(23,'22 тур',100),(24,'23 тур',100),(25,'24 тур',100),(26,'25 тур',100),(27,'26 тур',100),(28,'27 тур',100),(29,'28 тур',100),(30,'29 тур',100),(31,'30 тур',100),(32,'31 тур',100),(33,'32 тур',100),(34,'33 тур',100),(35,'34 тур',100),(36,'35 тур',100),(37,'36 тур',100),(38,'37 тур',100),(39,'38 тур',100),(40,'39 тур',100),(41,'40 тур',100),(42,'41 тур',100),(43,'ОР1',105),(44,'ОР2',105),(45,'ОР3',105),(46,'ОР4',105),(47,'1/512',110),(48,'1/256',120),(49,'1/128',130),(50,'1/64',140),(51,'1/32',150),(52,'1/16',160),(53,'1/8',170),(54,'1/4',180),(55,'1/2',190),(56,'Финал',200);
/*!40000 ALTER TABLE `stage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:38
