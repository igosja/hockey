-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `historytext`
--

DROP TABLE IF EXISTS `historytext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historytext` (
  `historytext_id` int(2) NOT NULL AUTO_INCREMENT,
  `historytext_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`historytext_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historytext`
--

LOCK TABLES `historytext` WRITE;
/*!40000 ALTER TABLE `historytext` DISABLE KEYS */;
INSERT INTO `historytext` VALUES (1,'Команда {team} зарегистрирована в Лиге'),(2,'Команда {team} перерегистрирована'),(3,'{user} принят на работу тренером-менеджером в команду {team}'),(4,'{user} покинул пост тренера-менеджера команды {team}'),(5,'{user} принят на работу заместителем менеджера в команду {team}'),(6,'{user} покинул пост заместителя менеджера команды {team}'),(7,'{user} принят на работу тренером-менеджером в сборную {national}'),(8,'{user} покинул пост тренера-менеджера сборной {national}'),(9,'{user} принят на работу заместителем менеджера в сборную {national}'),(10,'{user} покинул пост заместителя менеджера сборной {national}'),(11,'{user} избран президентом федерации {country}'),(12,'{user} покинул пост президента федерации {country}'),(13,'{user} избран заместителем президента федерации {country}'),(14,'{user} покинул пост заместителя президента федерации {country}'),(15,'Уровень строения {building} увеличен до {level} уровня'),(16,'Уровень строения {building} уменьшен до {level} уровня'),(17,'Стадион расширен до {capacity} мест'),(18,'Стадион уменьшен до {capacity} мест'),(19,'Произведен обмен любимых стилей игроков'),(20,'Произведен обмен спецвозможностей в команде'),(21,'За 1 место в регулярном чемпионате страны VIP-клуб сроком 3 мес.'),(22,'За 2 место в регулярном чемпионате страны VIP-клуб сроком 2 мес.'),(23,'За 3 место в регулярном чемпионате страны VIP-клуб сроком 1 мес.'),(24,'За победу в плей-офф чемпионата страны VIP-клуб сроком 2 мес.'),(25,'Финалисту плей-офф чемпионата страны VIP-клуб сроком 1 мес.'),(26,'{player} пришел из спортшколы в команду {team}'),(27,'Объявил об уходе на пенсию'),(28,'Вышел на пенсию'),(29,'Натренировал +1 балл силы на базе'),(30,'Натренировал совмещение {position} на базе'),(31,'Натренировал спецвозможность {special} на базе'),(32,'Получил +1 балл силы по результатам матча {game}'),(33,'Потерял -1 балл силы по результатам матча {game}'),(34,'Получил спецвозможность {special} по результатам чемпионата'),(35,'Натренировал бонусный +1 балл силы на базе'),(36,'Натренировал бонусное совмещение {position} на базе'),(37,'Натренировал бонусную спецвозможность {special} на базе'),(38,'Получил травму на {day} в матче {game}'),(39,'Перешел из команды {team} в команду {team}'),(40,'Перешел из команды {team} в команду {team} в результате обмена'),(41,'Перешел из команды {team} в команду {team} на правах аренды'),(42,'Вернулся в команду {team} из команды {team} по окончании аренды'),(43,'Продан Лиге командой {team}');
/*!40000 ALTER TABLE `historytext` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:46
