-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `basescout`
--

DROP TABLE IF EXISTS `basescout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basescout` (
  `basescout_id` int(2) NOT NULL AUTO_INCREMENT,
  `basescout_base_level` int(2) DEFAULT '0',
  `basescout_build_speed` int(2) DEFAULT '0',
  `basescout_distance` int(1) DEFAULT '0',
  `basescout_level` int(2) DEFAULT '0',
  `basescout_market_game_row` int(1) DEFAULT '0',
  `basescout_market_phisical` int(1) DEFAULT '0',
  `basescout_market_tire` int(1) DEFAULT '0',
  `basescout_my_style_count` int(2) DEFAULT '0',
  `basescout_my_style_price` int(11) DEFAULT '0',
  `basescout_opponent_game_row` int(1) DEFAULT '0',
  `basescout_opponent_phisical` int(1) DEFAULT '0',
  `basescout_opponent_tire` int(1) DEFAULT '0',
  `basescout_price_buy` int(11) DEFAULT '0',
  `basescout_price_sell` int(11) DEFAULT '0',
  `basescout_scout_speed_max` int(3) DEFAULT '0',
  `basescout_scout_speed_min` int(3) DEFAULT '0',
  PRIMARY KEY (`basescout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basescout`
--

LOCK TABLES `basescout` WRITE;
/*!40000 ALTER TABLE `basescout` DISABLE KEYS */;
INSERT INTO `basescout` VALUES (1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(2,1,1,1,1,0,0,0,5,25000,1,0,0,250000,187500,15,5),(3,1,2,1,2,0,0,0,10,50000,1,0,1,500000,375000,25,15),(4,2,3,2,3,0,0,0,15,75000,1,1,1,750000,562500,35,25),(5,2,4,2,4,1,0,0,20,100000,1,1,1,1000000,750000,45,35),(6,3,5,3,5,1,0,1,25,125000,1,1,1,1250000,937500,55,45),(7,3,6,3,6,1,1,1,30,150000,1,1,1,1500000,1125000,65,55),(8,4,7,4,7,1,1,1,35,175000,1,1,1,1750000,1312500,75,65),(9,4,8,4,8,1,1,1,40,200000,1,1,1,2000000,1500000,85,75),(10,5,9,5,9,1,1,1,45,225000,1,1,1,2250000,1687500,95,85),(11,5,10,5,10,1,1,1,50,250000,1,1,1,2500000,1875000,100,100);
/*!40000 ALTER TABLE `basescout` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:45
