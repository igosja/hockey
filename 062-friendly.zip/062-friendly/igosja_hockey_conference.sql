-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conference`
--

DROP TABLE IF EXISTS `conference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference` (
  `conference_id` int(11) NOT NULL AUTO_INCREMENT,
  `conference_difference` int(3) DEFAULT '0',
  `conference_game` int(2) DEFAULT '0',
  `conference_guest` int(2) DEFAULT '0',
  `conference_home` int(2) DEFAULT '0',
  `conference_loose` int(2) DEFAULT '0',
  `conference_loose_bullet` int(2) DEFAULT '0',
  `conference_loose_over` int(2) DEFAULT '0',
  `conference_pass` int(3) DEFAULT '0',
  `conference_place` int(5) DEFAULT '0',
  `conference_point` int(2) DEFAULT '0',
  `conference_score` int(3) DEFAULT '0',
  `conference_season_id` int(5) DEFAULT '0',
  `conference_team_id` int(5) DEFAULT '0',
  `conference_win` int(2) DEFAULT '0',
  `conference_win_bullet` int(2) DEFAULT '0',
  `conference_win_over` int(2) DEFAULT '0',
  PRIMARY KEY (`conference_id`),
  KEY `conference_place` (`conference_place`),
  KEY `conference_season_id` (`conference_season_id`),
  KEY `conference_team_id` (`conference_team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference`
--

LOCK TABLES `conference` WRITE;
/*!40000 ALTER TABLE `conference` DISABLE KEYS */;
INSERT INTO `conference` VALUES (1,-6,41,20,21,19,1,2,95,15,58,89,1,33,17,1,1),(2,13,41,20,21,11,6,1,59,2,72,72,1,34,19,3,1),(3,18,41,20,21,12,5,1,63,4,70,81,1,67,18,5,0),(4,18,41,20,21,10,2,1,58,1,81,76,1,68,22,4,2),(5,6,41,21,20,14,3,1,69,8,66,75,1,101,16,6,1),(6,-3,41,20,21,17,5,0,67,14,59,64,1,102,16,3,0),(7,16,41,21,20,19,0,0,62,10,64,78,1,135,20,1,1),(8,11,41,20,21,15,2,1,57,7,67,68,1,136,18,3,2),(9,-14,41,20,21,19,2,2,88,21,54,74,1,169,14,2,2),(10,20,41,21,20,10,8,1,49,3,71,69,1,170,18,4,0),(11,9,41,21,20,14,5,0,66,6,68,75,1,203,19,3,0),(12,-21,41,21,20,17,6,1,107,18,56,86,1,204,15,2,0),(13,-7,41,21,20,19,3,1,81,20,54,74,1,237,14,2,2),(14,-12,41,21,20,19,2,2,97,22,53,85,1,238,13,5,0),(15,0,41,20,21,16,4,0,72,12,62,72,1,271,16,4,1),(16,5,41,21,20,15,2,1,72,11,64,77,1,272,15,6,2),(17,0,41,21,20,13,5,2,93,9,65,93,1,305,16,3,2),(18,11,41,20,21,17,5,2,62,17,57,73,1,306,16,0,1),(19,13,41,20,21,14,1,1,62,5,69,75,1,339,17,8,0),(20,-28,41,20,21,20,2,1,96,23,49,68,1,340,10,4,4),(21,-13,41,21,20,17,2,0,74,13,60,61,1,373,14,6,2),(22,-12,41,21,20,16,3,6,85,19,55,73,1,374,14,2,0),(23,-19,41,21,20,20,4,2,87,24,45,68,1,407,9,2,4),(24,-5,41,20,21,19,3,0,81,16,57,76,1,408,16,2,1);
/*!40000 ALTER TABLE `conference` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:38
