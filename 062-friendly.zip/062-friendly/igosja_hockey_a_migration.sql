-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `a_migration`
--

DROP TABLE IF EXISTS `a_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `a_migration` (
  `migration_id` int(11) NOT NULL AUTO_INCREMENT,
  `migration_date` int(11) DEFAULT '0',
  `migration_file` varchar(255) NOT NULL,
  PRIMARY KEY (`migration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `a_migration`
--

LOCK TABLES `a_migration` WRITE;
/*!40000 ALTER TABLE `a_migration` DISABLE KEYS */;
INSERT INTO `a_migration` VALUES (1,1515568195,'1473578000_achievement.php'),(2,1515568195,'1473578000_achievementplayer.php'),(3,1515568195,'1473578000_base.php'),(4,1515568195,'1473578000_basemedical.php'),(5,1515568195,'1473578000_basephisical.php'),(6,1515568195,'1473578000_baseschool.php'),(7,1515568195,'1473578000_basescout.php'),(8,1515568195,'1473578000_basetraining.php'),(9,1515568195,'1473578000_building.php'),(10,1515568195,'1473578000_buildingbase.php'),(11,1515568195,'1473578000_buildingstadium.php'),(12,1515568195,'1473578000_championship.php'),(13,1515568195,'1473578000_city.php'),(14,1515568195,'1473578000_conference.php'),(15,1515568195,'1473578000_constructiontype.php'),(16,1515568195,'1473578000_country.php'),(17,1515568195,'1473578000_daytype.php'),(18,1515568195,'1473578000_debug.php'),(19,1515568195,'1473578000_division.php'),(20,1515568195,'1473578000_electionnational.php'),(21,1515568195,'1473578000_electionnationalapplication.php'),(22,1515568195,'1473578000_electionnationalapplicationplayer.php'),(23,1515568195,'1473578000_electionnationaluser.php'),(24,1515568195,'1473578000_electionnationalvice.php'),(25,1515568195,'1473578000_electionnationalviceapplication.php'),(26,1515568195,'1473578000_electionnationalviceuser.php'),(27,1515568195,'1473578000_electionpresident.php'),(28,1515568195,'1473578000_electionpresidentapplication.php'),(29,1515568195,'1473578000_electionpresidentuser.php'),(30,1515568195,'1473578000_electionpresidentvice.php'),(31,1515568195,'1473578000_electionpresidentviceapplication.php'),(32,1515568195,'1473578000_electionpresidentviceuser.php'),(33,1515568195,'1473578000_electionstatus.php'),(34,1515568195,'1473578000_event.php'),(35,1515568195,'1473578000_eventtextbullet.php'),(36,1515568195,'1473578000_eventtextgoal.php'),(37,1515568195,'1473578000_eventtextpenalty.php'),(38,1515568195,'1473578000_eventtype.php'),(39,1515568195,'1473578000_finance.php'),(40,1515568195,'1473578000_financetext.php'),(41,1515568195,'1473578000_forumchapter.php'),(42,1515568195,'1473578000_forumgroup.php'),(43,1515568195,'1473578000_forummessage.php'),(44,1515568195,'1473578000_forumtheme.php'),(45,1515568195,'1473578000_friendlyinvite.php'),(46,1515568195,'1473578000_friendlyinvitestatus.php'),(47,1515568195,'1473578000_friendlystatus.php'),(48,1515568195,'1473578000_game.php'),(49,1515568195,'1473578000_gamecomment.php'),(50,1515568195,'1473578000_history.php'),(51,1515568195,'1473578000_historytext.php'),(52,1515568195,'1473578000_league.php'),(53,1515568195,'1473578000_leaguedistribution.php'),(54,1515568195,'1473578000_line.php'),(55,1515568195,'1473578000_lineup.php'),(56,1515568195,'1473578000_message.php'),(57,1515568195,'1473578000_money.php'),(58,1515568195,'1473578000_moneytext.php'),(59,1515568195,'1473578000_mood.php'),(60,1515568195,'1473578000_name.php'),(61,1515568195,'1473578000_namecountry.php'),(62,1515568195,'1473578000_national.php'),(63,1515568195,'1473578000_nationaltype.php'),(64,1515568195,'1473578000_nationalvotestep.php'),(65,1515568195,'1473578000_news.php'),(66,1515568195,'1473578000_newscomment.php'),(67,1515568195,'1473578000_offseason.php'),(68,1515568195,'1473578000_participantchampionship.php'),(69,1515568195,'1473578000_participantleague.php'),(70,1515568195,'1473578000_payment.php'),(71,1515568195,'1473578000_phisical.php'),(72,1515568195,'1473578000_phisicalchange.php'),(73,1515568195,'1473578000_player.php'),(74,1515568195,'1473578000_playerposition.php'),(75,1515568195,'1473578000_playerspecial.php'),(76,1515568195,'1473578000_position.php'),(77,1515568195,'1473578000_ratingchangeplayer.php'),(78,1515568195,'1473578000_ratingchangeteam.php'),(79,1515568195,'1473578000_ratingchapter.php'),(80,1515568195,'1473578000_ratingcountry.php'),(81,1515568195,'1473578000_ratingteam.php'),(82,1515568195,'1473578000_ratingtype.php'),(83,1515568195,'1473578000_ratinguser.php'),(84,1515568195,'1473578000_relation.php'),(85,1515568195,'1473578000_rent.php'),(86,1515568195,'1473578000_rentapplication.php'),(87,1515568195,'1473578000_rentposition.php'),(88,1515568195,'1473578000_rentspecial.php'),(89,1515568195,'1473578000_review.php'),(90,1515568195,'1473578000_rosterphrase.php'),(91,1515568195,'1473578000_rude.php'),(92,1515568195,'1473578000_rule.php'),(93,1515568195,'1473578000_schedule.php'),(94,1515568195,'1473578000_school.php'),(95,1515568195,'1473578000_scout.php'),(96,1515568195,'1473578000_season.php'),(97,1515568195,'1473578000_sex.php'),(98,1515568195,'1473578000_site.php'),(99,1515568195,'1473578000_special.php'),(100,1515568195,'1473578000_stadium.php'),(101,1515568195,'1473578000_stage.php'),(102,1515568195,'1473578000_statisticchapter.php'),(103,1515568195,'1473578000_statisticplayer.php'),(104,1515568196,'1473578000_statisticteam.php'),(105,1515568196,'1473578000_statistictype.php'),(106,1515568196,'1473578000_style.php'),(107,1515568196,'1473578000_surname.php'),(108,1515568196,'1473578000_surnamecountry.php'),(109,1515568196,'1473578000_swissgame.php'),(110,1515568196,'1473578000_swisstable.php'),(111,1515568196,'1473578000_tactic.php'),(112,1515568196,'1473578000_team.php'),(113,1515568196,'1473578000_teamask.php'),(114,1515568196,'1473578000_teamvisitor.php'),(115,1515568196,'1473578000_teamwork.php'),(116,1515568196,'1473578000_tournamenttype.php'),(117,1515568196,'1473578000_training.php'),(118,1515568196,'1473578000_transfer.php'),(119,1515568196,'1473578000_transferapplication.php'),(120,1515568196,'1473578000_transferposition.php'),(121,1515568196,'1473578000_transferspecial.php'),(122,1515568196,'1473578000_transfervote.php'),(123,1515568196,'1473578000_user.php'),(124,1515568196,'1473578000_userrating.php'),(125,1515568196,'1473578000_userrole.php'),(126,1515568196,'1473578000_vote.php'),(127,1515568196,'1473578000_voteanswer.php'),(128,1515568196,'1473578000_votestatus.php'),(129,1515568196,'1473578000_voteuser.php'),(130,1515568196,'1473578000_worldcup.php');
/*!40000 ALTER TABLE `a_migration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:39
