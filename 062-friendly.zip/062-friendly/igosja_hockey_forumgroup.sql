-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: igosja_hockey
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forumgroup`
--

DROP TABLE IF EXISTS `forumgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forumgroup` (
  `forumgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `forumgroup_count_message` int(11) DEFAULT '0',
  `forumgroup_count_theme` int(11) DEFAULT '0',
  `forumgroup_country_id` int(3) DEFAULT '0',
  `forumgroup_description` text,
  `forumgroup_forumchapter_id` int(11) DEFAULT '0',
  `forumgroup_last_date` int(11) DEFAULT '0',
  `forumgroup_last_forummessage_id` int(11) DEFAULT '0',
  `forumgroup_last_forumtheme_id` int(11) DEFAULT '0',
  `forumgroup_last_user_id` int(11) DEFAULT '0',
  `forumgroup_name` varchar(255) DEFAULT NULL,
  `forumgroup_order` int(3) DEFAULT '0',
  `forumgroup_user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`forumgroup_id`),
  KEY `forumgroup_forumchapter_id` (`forumgroup_forumchapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forumgroup`
--

LOCK TABLES `forumgroup` WRITE;
/*!40000 ALTER TABLE `forumgroup` DISABLE KEYS */;
INSERT INTO `forumgroup` VALUES (1,0,0,0,'вопросы и комментарии о лиге глобального характера, творчество, что нравится/не нравится',1,0,0,0,0,'О Лиге',1,0),(2,0,0,0,'сверxсрочные проблемы, не терпящие отлагательств, а то будет поздно - остальное в баги или вопросы новичков',1,0,0,0,0,'Скорая помощь',2,0),(3,0,0,0,'для обсуждения с опытными менеджерами возникающих у новичков самых простых вопросов',1,0,0,0,0,'Вопросы новичков',3,0),(4,0,0,0,'(пере)регистрация, выставление/раздача свободных команд, переходы из клуба в клуб, верните команду и т.д.',1,0,0,0,0,'Регистрация и команды',4,0),(5,0,0,0,'высказывание интересных мыслей и конкретных идей по поводу развития лиги',1,0,0,0,0,'Идеи и предложения',5,0),(6,0,0,0,'обсуждение, трактовка, серьезные вопросы по поводу действующих правил',1,0,0,0,0,'Правила',6,0),(7,0,0,0,'если хотите договориться о купле/продаже игроков',2,0,0,0,0,'Трансферы',7,0),(8,0,0,0,'поиск соперников на товы',2,0,0,0,0,'Товарищеские Матчи',8,0),(9,0,0,0,'если хотите договориться об аренде игроков',2,0,0,0,0,'Аренда',9,0),(10,0,0,0,'встречи менеджеров в реале - на стадион сходить, пивка попить',3,0,0,0,0,'Встречи',10,0),(11,0,0,0,'обсуждение реальных событий, хоккейный оффтопик',3,0,0,0,0,'Реальный хоккей',11,0),(12,0,0,0,'обсуждение всего чего угодно за пределами Лиги',3,0,0,0,0,'Оффтопик',12,0),(13,0,0,18,'национальный форум',4,0,0,0,0,'Белоруссия',13,0),(14,0,0,43,'национальный форум',4,0,0,0,0,'Германия',14,0),(15,0,0,71,'национальный форум',4,0,0,0,0,'Канада',15,0),(16,0,0,122,'национальный форум',4,0,0,0,0,'Норвегия',16,0),(17,0,0,133,'национальный форум',4,0,0,0,0,'Россия',17,0),(18,0,0,151,'национальный форум',4,0,0,0,0,'Словакия',18,0),(19,0,0,157,'национальный форум',4,0,0,0,0,'США',19,0),(20,0,0,171,'национальный форум',4,0,0,0,0,'Украина',20,0),(21,0,0,176,'национальный форум',4,0,0,0,0,'Финляндия',21,0),(22,0,0,182,'национальный форум',4,0,0,0,0,'Чехия',22,0),(23,0,0,184,'национальный форум',4,0,0,0,0,'Швейцария',23,0),(24,0,0,185,'национальный форум',4,0,0,0,0,'Швеция',24,0);
/*!40000 ALTER TABLE `forumgroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-12 14:50:37
