<?php
/**
 * @var $count_item integer
 * @var $summary_from integer
 * @var $summary_to integer
 */
?>
<div class="summary">
    Показаны записи <b><?= $summary_from; ?>-<?= $summary_to; ?></b> из <b><?= $count_item; ?></b>.
</div>