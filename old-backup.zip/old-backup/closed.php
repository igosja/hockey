<?php

include(__DIR__ . '/include/include.php');

$seo_title          = 'Технические работы ';
$seo_description    = 'На сайте Вирутальной Хоккейной Лиги проводятся технические работы.';
$seo_keywords       = 'технические работы';

include(__DIR__ . '/view/layout/main.php');